﻿// ==================================================================================
// <file="ILevelToLoad.cs" product="Homeward">
// <date>2015-01-11</date>
// ==================================================================================

#region Header Files

using UnityEngine;
using System.Collections;

#endregion

public interface ILevelToLoad 
{
	void LoadLevel();
}
