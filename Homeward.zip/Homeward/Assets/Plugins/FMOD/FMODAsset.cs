using UnityEngine;

public class FMODAsset : ScriptableObject
{
	public string path;
	public string id; // Note: variable name 'guid' is not allowed in Unity
};
